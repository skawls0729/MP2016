package com.example.mphw4_2;

import android.content.Context;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.util.Log;
import android.view.View;

/**
 * Created by 남지니 on 2016-05-25.
 */
public class Maze extends View {
    boolean[][] flag = new boolean[16][24];
    int width = 16, height = 24;
    int[][] maze = new int[width][height]; // The maze
    boolean[][] wasHere = new boolean[width][height];
    boolean[][] correctPath = new boolean[width][height]; // The solution to the maze
    int startX = 0, startY = 1; // Starting X and Y values of maze
    int endX = 14, endY = 21;     // Ending X and Y values of maze

    //Bitmap [][] block = new Bitmap[24][16];
    public Maze(Context context) {
        super(context);
        solveMaze();
        String r = "";
        for (int i = 0; i < 24; i++) {
            for (int j = 0; j < 16; j++) {
                r = r + maze[j][i];
            }
            Log.d("solve", r);
            r = "";
        }
    }

    public void onDraw(Canvas canvas) {
        Paint pntB = new Paint();
        pntB.setColor(Color.BLACK);
        Paint pntW = new Paint();
        pntW.setColor(Color.WHITE);
        Paint pntR = new Paint();
        pntR.setColor(Color.RED);
        Log.d("a", "" + maze[0][0]);
        for (int i = 0; i < 16; i++) {
            for (int j = 0; j < 24; j++) {
                if ((i == startX && j == startY) || (i == endX && j == endY))
                    canvas.drawRect(i * 50, j * 50, i * 50 + 50, j * 50 + 50,pntR);
                else{
                    if (maze[i][j] == 1) {
                        canvas.drawRect(i * 50, j * 50, i * 50 + 50, j * 50 + 50, pntW);
                    } else {
                        canvas.drawRect(i * 50, j * 50, i * 50 + 50, j * 50 + 50, pntB);
                    }
                }
            }
        }
        canvas.drawBitmap(BitmapFactory.decodeResource(getResources(),R.drawable.walk2),0,50,null);
    }

    public void solveMaze() {
        while (true) {
            generateMaze(); // Create Maze (1 = path, 2 = wall)
            for (int row = 0; row < maze.length; row++)
                // Sets boolean Arrays to default values
                for (int col = 0; col < maze[row].length; col++) {
                    wasHere[row][col] = false;
                    correctPath[row][col] = false;
                    //maze[row][col]=2;
                }
            boolean b = recursiveSolve(startX, startY);
            if (b)
                break;
            // Will leave you with a boolean array (correctPath)
            // with the path indicated by true values.
            // If b is false, there is no solution to the maze
        }
    }

    private void generateMaze() {
        for (int i = 0; i < 16; i++) {
            for (int j = 0; j < 24; j++) {
                if (Math.random() >= 0.55)
                    maze[i][j] = 1;
                else
                    maze[i][j] = 2;
                if(i>=15 || j >=22)
                    maze[i][j]=2;
            }
        }
        maze[startX][startY] = 1;
        maze[endX][endY] = 1;
    }

    public boolean recursiveSolve(int x, int y) {
        if (x == endX && y == endY) return true; // If you reached the end
        if (maze[x][y] == 2 || wasHere[x][y]) return false;
        // If you are on a wall or already were here
        wasHere[x][y] = true;
        if (x != 0) // Checks if not on left edge
            if (recursiveSolve(x - 1, y)) { // Recalls method one to the left
                correctPath[x][y] = true; // Sets that path value to true;
                return true;
            }
        if (x != width - 1) // Checks if not on right edge
            if (recursiveSolve(x + 1, y)) { // Recalls method one to the right
                correctPath[x][y] = true;
                return true;
            }
        if (y != 0)  // Checks if not on top edge
            if (recursiveSolve(x, y - 1)) { // Recalls method one up
                correctPath[x][y] = true;
                return true;
            }
        if (y != height - 1) // Checks if not on bottom edge
            if (recursiveSolve(x, y + 1)) { // Recalls method one down
                correctPath[x][y] = true;
                return true;
            }
        return false;
    }
}
