package com.example.mphw4_1;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.view.MotionEvent;
import android.view.View;

/**
 * Created by 남지니 on 2016-05-25.
 */
public class MyPongPong extends View {

    boolean[][] pongsB = new boolean[12][8];
    float[][] pongsX = new float[12][8];
    float[][] pongsY = new float[12][8];
    Bitmap [][]bitmaps = new Bitmap[12][8];
    public MyPongPong(Context context) {
        super(context);
        for (int i = 0; i < 12; i++) {
            for (int j = 0; j < 8; j++) {
                pongsB[i][j]=true;
                pongsX[i][j]=j*100;
                pongsY[i][j]=i*100;
            }
        }
    }
    @Override
    public void onDraw(Canvas canvas) {
        for(int i=0;i<12;i++)
        {
            for(int j=0;j<8;j++)
            {
                if(pongsB[i][j]==true)
                    bitmaps[i][j]=BitmapFactory.decodeResource(getResources(),R.drawable.trues);
                else
                    bitmaps[i][j]=BitmapFactory.decodeResource(getResources(),R.drawable.falses);
                canvas.drawBitmap(bitmaps[i][j],j*100,i*100,null);//left top
            }
        }
    }
    @Override
    public boolean onTouchEvent(MotionEvent event) {
        float eventX = event.getX();
        float eventY = event.getY();
        if(event.getAction() == MotionEvent.ACTION_DOWN)
        {
            float x = ((int)eventX/100)*100 + 50; // 터치한 지점에서 가장 가까운 원의 중심 찾기
            float y = ((int)eventY/100)*100 + 50; // 터치한 지점에서 가장 가까운 원의 중심 찾기
            double dist = Math.pow(x - eventX,2) + Math.pow(y-eventY,2);
            dist= Math.sqrt(dist);
            if(dist<=50)
            {
                pongsB[((int)eventY/100)][((int)eventX/100)] = false; // 해당지점의 flag 를 false로 바꿈
            }
        }
        invalidate();
        return true;
    }
}
