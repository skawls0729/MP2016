package com.example.mphw4_2;

import android.app.Activity;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Rect;
import android.util.AttributeSet;
import android.util.Log;
import android.view.MotionEvent;
import android.view.SurfaceHolder;
import android.view.SurfaceView;
import android.view.Window;
import android.widget.Toast;

/**
 * Created by 남지니 on 2016-05-25.
 */public class pencle extends SurfaceView implements SurfaceHolder.Callback {
    Canvas cacheCanvas;
    Bitmap backBuffer;
    int width, height, clientHeight;
    Paint paint;
    Context context;
    SurfaceHolder mHolder;
    int widths = 16, heights = 24;
    int[][] maze = new int[widths][heights]; // The maze
    boolean[][] wasHere = new boolean[widths][heights];
    boolean[][] correctPath = new boolean[widths][heights]; // The solution to the maze
    int startX = 0, startY = 1; // Starting X and Y values of maze
    int endX = 14, endY = 21;     // Ending X and Y values of maze
    int humanX=0,humanY=1;// coordinate of person
    boolean humanFlag = false; // for drawing
    public pencle(Context context) {
        super(context);
        this.context = context;
        init();
    }

    public pencle(Context context, AttributeSet attrs) {
        super(context, attrs);
        this.context = context;
        init();
    }

    private void init() {
        mHolder = getHolder();
        mHolder.addCallback(this);
        solveMaze();
        String r = "";
        for (int i = 0; i < 24; i++) {
            for (int j = 0; j < 16; j++) {
                r = r + maze[j][i];
            }
            Log.d("solve", r);
            r = "";
        }
    }

    public void surfaceChanged(SurfaceHolder holder, int format, int width,
                               int height) {
    }

    public void surfaceCreated(SurfaceHolder holder) {
        width = getWidth();
        height = getHeight();
        cacheCanvas = new Canvas();
        backBuffer = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888); //back buffer
        cacheCanvas.setBitmap(backBuffer);
        cacheCanvas.drawColor(Color.WHITE);
        paint = new Paint();
        paint.setColor(Color.BLUE);
        paint.setStrokeWidth(10);
        paint.setStrokeCap(Paint.Cap.ROUND);
        paint.setStrokeJoin(Paint.Join.ROUND);
        draw();
    }

    public void surfaceDestroyed(SurfaceHolder holder) {

    }

    int lastX, lastY, currX, currY;
    boolean isDeleting;

    @Override
    public boolean onTouchEvent(MotionEvent event) {
        super.onTouchEvent(event);
        int action = event.getAction();
        int x=0;
        int y=0;
        switch (action & MotionEvent.ACTION_MASK) {
            case MotionEvent.ACTION_DOWN:
                lastX = (int) event.getX();
                lastY = (int) event.getY();
                x = lastX/50;
                y = lastY/50;
                if(x==humanX && y==humanY)// 사람이 있는 블럭을 눌렀을때부터 사람을 움직이게 하기 위해서
                    humanFlag= true;
                break;
            case MotionEvent.ACTION_MOVE:
                if (isDeleting) break;
                currX = (int) event.getX();
                currY = (int) event.getY();
                cacheCanvas.drawLine(lastX, lastY, currX, currY, paint);
                lastX = currX;
                lastY = currY;
                //여기서 currxy가 미로로 가면 아웃

                if(humanFlag==false)//만약 사람을 클릭하고 그린게 아니라면 그림을 초기화
                {
                    cacheCanvas.drawColor(Color.WHITE);
                    isDeleting = true;
                }
                if(maze[(int)(lastX/50)][(int)(lastY)/50]==2) {//만약 사람이 미로에 닿으면 초기화
                    Log.d("tag",""+maze[x][y]+""+x+""+y);
                    cacheCanvas.drawColor(Color.WHITE);
                    isDeleting = true;
                    humanX=0;
                    humanY=1;
                    humanFlag=false;
                }
                break;
            case MotionEvent.ACTION_UP:
                if (isDeleting) isDeleting = false;
                if(humanFlag) {//사람으로부터 그런게 아니면 사람이 움직이지 않음
                    humanX = lastX / 50;
                    humanY = lastY / 50;
                    humanFlag = false;
                }break;
            case MotionEvent.ACTION_POINTER_DOWN:
                cacheCanvas.drawColor(Color.WHITE);
                isDeleting = true;
                break;
            case MotionEvent.ACTION_POINTER_UP:
                break;
        }
        draw(); // SurfaceView에 그리는 function을 직접 제작 및 호출
        return true;
    }

    protected void draw() {
        if (clientHeight == 0) {
            clientHeight = getClientHeight();
            height = clientHeight;
            backBuffer = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888);
            cacheCanvas.setBitmap(backBuffer);
            cacheCanvas.drawColor(Color.WHITE);
        }
        Canvas canvas = null;
        try {
            canvas = mHolder.lockCanvas(null);
            //back buffer에 그려진 비트맵을 스크린 버퍼에 그린다
            canvas.drawBitmap(backBuffer, 0, 0, paint);
            Paint pntB = new Paint();
            pntB.setColor(Color.BLACK);
            Paint pntW = new Paint();
            pntW.setColor(Color.WHITE);
            Paint pntR = new Paint();
            pntR.setColor(Color.RED);
            for (int i = 0; i < 16; i++) {
                for (int j = 0; j < 24; j++) {
                    if ((i == startX && j == startY) || (i == endX && j == endY))
                        canvas.drawRect(i * 50, j * 50, i * 50 + 50, j * 50 + 50,pntR);
                    else{
                        if (maze[i][j] == 1) {
                           // canvas.drawRect(i * 50, j * 50, i * 50 + 50, j * 50 + 50, pntW);
                        } else {
                            canvas.drawRect(i * 50, j * 50, i * 50 + 50, j * 50 + 50, pntB);
                        }
                    }
                }
            }
            canvas.drawBitmap(BitmapFactory.decodeResource(getResources(), R.drawable.walk2),humanX*50,humanY*50,null);
            if(humanX == endX && humanY == endY)
            {
                Toast.makeText(context,"Clear\n new generate Maze",Toast.LENGTH_SHORT).show();
                humanX=startX;
                humanY=startY;
                solveMaze();
            }

        } catch (Exception ex) {
            ex.printStackTrace();
        } finally {
            if (mHolder != null) mHolder.unlockCanvasAndPost(canvas);
        }
    }

    /* 상태바, 타이틀바를 제외한 클라이언트 영역의 높이를 구한다 */
    private int getClientHeight() {
        Rect rect = new Rect();
        Window window = ((Activity) context).getWindow();
        window.getDecorView().getWindowVisibleDisplayFrame(rect);
        int statusBarHeight = rect.top;
        int contentViewTop = window.findViewById(Window.ID_ANDROID_CONTENT).getTop();
        int titleBarHeight = contentViewTop - statusBarHeight;
        return ((Activity) context).getWindowManager().getDefaultDisplay().
                getHeight() - statusBarHeight - titleBarHeight;
    }

    public void solveMaze() {
        while (true) {
            generateMaze(); // Create Maze (1 = path, 2 = wall)
            for (int row = 0; row < maze.length; row++)
                // Sets boolean Arrays to default values
                for (int col = 0; col < maze[row].length; col++) {
                    wasHere[row][col] = false;
                    correctPath[row][col] = false;
                    //maze[row][col]=2;
                }
            boolean b = recursiveSolve(startX, startY);
            if (b)
                break;
            // Will leave you with a boolean array (correctPath)
            // with the path indicated by true values.
            // If b is false, there is no solution to the maze
        }
    }

    private void generateMaze() {
        for (int i = 0; i < 16; i++) {
            for (int j = 0; j < 24; j++) {
                if (Math.random() >= 0.55)
                    maze[i][j] = 1;
                else
                    maze[i][j] = 2;
                if(i>=15 || j >=22)
                    maze[i][j]=2;
            }
        }
        maze[startX][startY] = 1;
        maze[endX][endY] = 1;
    }

    public boolean recursiveSolve(int x, int y) {
        if (x == endX && y == endY) return true; // If you reached the end
        if (maze[x][y] == 2 || wasHere[x][y]) return false;
        // If you are on a wall or already were here
        wasHere[x][y] = true;
        if (x != 0) // Checks if not on left edge
            if (recursiveSolve(x - 1, y)) { // Recalls method one to the left
                correctPath[x][y] = true; // Sets that path value to true;
                return true;
            }
        if (x != width - 1) // Checks if not on right edge
            if (recursiveSolve(x + 1, y)) { // Recalls method one to the right
                correctPath[x][y] = true;
                return true;
            }
        if (y != 0)  // Checks if not on top edge
            if (recursiveSolve(x, y - 1)) { // Recalls method one up
                correctPath[x][y] = true;
                return true;
            }
        if (y != height - 1) // Checks if not on bottom edge
            if (recursiveSolve(x, y + 1)) { // Recalls method one down
                correctPath[x][y] = true;
                return true;
            }
        return false;
    }
}