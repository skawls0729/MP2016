package com.example.mphw4_2;

import android.app.Activity;
import android.content.Context;
import android.graphics.Canvas;
import android.os.Bundle;
import android.view.SurfaceHolder;

public class MainActivity extends Activity {
    MyThread myThread;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        pencle p = new pencle(this);
        setContentView(p);
    }

    public class MyThread extends Thread
    {
        boolean mRun;
        Canvas mcanvas;
        SurfaceHolder surfaceHolder;
        Context context;
        pencle msurfacePanel;

        public MyThread(SurfaceHolder sholder, Context ctx, pencle spanel)
        {
            surfaceHolder = sholder;
            context = ctx;
            mRun = false;
            msurfacePanel = spanel;
        }

    void setRunning(boolean bRun)
    {
        mRun = bRun;
    }
    @Override
    public void run()
    {
        super.run();
        while (mRun)
        {
            mcanvas = surfaceHolder.lockCanvas();
            if (mcanvas != null)
            {
                msurfacePanel.draw(mcanvas);
                surfaceHolder.unlockCanvasAndPost(mcanvas);
            }

        }

    }

}
}
